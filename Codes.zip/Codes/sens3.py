"""
=============================================================================
 DUYARLILIK ANALİZİ — Senaryo Olasılık Ağırlıklandırması (p_s)
 -----------------------------------------------------------------------------
 Bu script'te eski senaryolar dosyası KULLANILMAZ.
 Asimetrik (gerçek favorable / adverse) senaryolar script içinde tanımlanır.

 5 ağırlık yapısı denenir:
   - strongly_adverse   : adverse senaryolara yüksek ağırlık
   - mildly_adverse
   - equal              (baseline = eşit ağırlık 0.20)
   - mildly_favorable
   - strongly_favorable : favorable senaryolara yüksek ağırlık

 Çıktılar:
   - prob_sensitivity_summary.csv
   - prob_sensitivity_pareto.csv
   - prob_sensitivity_dc_freq.csv
   - prob_sensitivity.png
=============================================================================
"""

import os
import sys
import time
from collections import Counter
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import gurobipy as gp
from gurobipy import GRB

sys.stdout.reconfigure(line_buffering=True)

# =============================================================================
# 0. VERİ YÜKLEME (scenarios.csv KULLANILMAZ)
# =============================================================================

DATA_DIR = os.path.dirname(os.path.abspath(__file__))

donors_df   = pd.read_csv(os.path.join(DATA_DIR, "donors.csv"))
dc_df       = pd.read_csv(os.path.join(DATA_DIR, "distribution_centers.csv"))
charity_df  = pd.read_csv(os.path.join(DATA_DIR, "charities.csv"))
dist_df     = pd.read_csv(os.path.join(DATA_DIR, "distance_matrix.csv"))

donors    = donors_df["donor_id"].tolist()
dcs       = dc_df["dc_id"].tolist()
charities = charity_df["charity_id"].tolist()
I, J, K = len(donors), len(dcs), len(charities)

# =============================================================================
# 1. ASİMETRİK SENARYOLARI BURADA TANIMLA
# =============================================================================
# Sıralama: S1 = en adverse (az arz + çok talep), S5 = en favorable (çok arz + az talep)
# Bu sıralama önemli, çünkü olasılık ağırlıkları bu sıraya göre uygulanacak.

scenario_df = pd.read_csv(os.path.join(DATA_DIR, "scenarios.csv"))

# (İstersen referans için eski senaryolar da burada — KULLANILMIYOR ama saklı)
# old_scenarios = pd.DataFrame([
#     {"scenario_id": "S1", "donor_supply_multiplier": 0.7, "demand_multiplier": 0.9, "traffic_multiplier": 1.0},
#     {"scenario_id": "S2", "donor_supply_multiplier": 0.9, "demand_multiplier": 1.0, "traffic_multiplier": 1.1},
#     {"scenario_id": "S3", "donor_supply_multiplier": 1.0, "demand_multiplier": 1.1, "traffic_multiplier": 1.2},
#     {"scenario_id": "S4", "donor_supply_multiplier": 1.2, "demand_multiplier": 1.2, "traffic_multiplier": 1.3},
#     {"scenario_id": "S5", "donor_supply_multiplier": 1.3, "demand_multiplier": 1.3, "traffic_multiplier": 1.4},
# ])


S = len(scenario_df)
supply_mult = scenario_df["donor_supply_multiplier"].values
demand_mult = scenario_df["demand_multiplier"].values

print("="*72, flush=True)
print(" SENARYO OLASILIK AĞIRLIKLANDIRMA DUYARLILIK ANALİZİ", flush=True)
print("="*72, flush=True)
print(" Asimetrik senaryolar (script içinde tanımlı):", flush=True)
for s in range(S):
    print(f"   S{s+1}: arz_mult={supply_mult[s]:.2f}, talep_mult={demand_mult[s]:.2f}",
          flush=True)
print("="*72, flush=True)

# =============================================================================
# 2. PARAMETRE HESAPLAMA
# =============================================================================

supply_base = donors_df.set_index("donor_id")["avg_daily_surplus_kg"]
demand_base = charity_df.set_index("charity_id")["avg_daily_demand_kg"]

S_is = {(i, s): float(supply_base[donors[i]]) * float(supply_mult[s])
        for i in range(I) for s in range(S)}
D_ks = {(k, s): float(demand_base[charities[k]]) * float(demand_mult[s])
        for k in range(K) for s in range(S)}

C_j  = {j: float(dc_df.iloc[j]["capacity_kg"]) for j in range(J)}
fc_j = {j: float(dc_df.iloc[j]["fixed_cost"])  for j in range(J)}
refrig_cost_map = {"high": 1400.0, "medium": 1000.0, "low": 600.0}
eps_j = {j: refrig_cost_map.get(dc_df.iloc[j]["refrigeration_level"], 1000.0)
         for j in range(J)}

kappa0, theta_T, eps_ac, R_gas = 0.05, 4.0, 1500.0, 8.314
kap = kappa0 * np.exp(-eps_ac / (R_gas * (theta_T + 273.15)))
max_shelf = donors_df["shelf_life_hours"].max()
L_i = {did: 0.5 + 0.5 * (
        float(donors_df.loc[donors_df["donor_id"] == did,
                            "shelf_life_hours"].values[0]) / max_shelf)
       for did in donors}

dist_lookup = dist_df.set_index(["origin_id", "destination_id"])["distance_km"].to_dict()
def get_dist(o, d):
    v = dist_lookup.get((o, d))
    if v is not None: return float(v)
    v = dist_lookup.get((d, o))
    return float(v) if v is not None else 9999.0

d_ij = {(i, j): get_dist(donors[i], dcs[j])    for i in range(I) for j in range(J)}
d_jk = {(j, k): get_dist(dcs[j], charities[k]) for j in range(J) for k in range(K)}

alpha_ij, beta_jk = {}, {}
for i in range(I):
    for j in range(J):
        alpha_ij[i, j] = min(max(1.0 - L_i[donors[i]] * np.exp(-kap * d_ij[i, j]), 0.0), 0.99)
for j in range(J):
    for k in range(K):
        beta_jk[j, k] = min(max(1.0 - np.exp(-kap * d_jk[j, k]), 0.0), 0.99)

GAMMA, PHI, PI_P, ETA = 0.05, 0.03, 2.0, 0.08
M_BIG = max(S_is.values()) * I * 1.5
MIN_SERVICE_RATE = 0.30
total_demand_s = {s: sum(D_ks[k, s] for k in range(K)) for s in range(S)}
total_supply_s = {s: sum(S_is[i, s] for i in range(I)) for s in range(S)}

# =============================================================================
# 3. OLASILIK YAPISI
# =============================================================================
# Ağırlıklar S1 → S5 sıralı. S1 adverse, S5 favorable olduğu için:
#  - strongly_adverse: S1'e en yüksek ağırlık
#  - strongly_favorable: S5'e en yüksek ağırlık

WEIGHT_SCHEMES = {
    "strongly_adverse":   [0.50, 0.25, 0.15, 0.07, 0.03],
    "mildly_adverse":     [0.35, 0.25, 0.20, 0.13, 0.07],
    "equal":              [0.20, 0.20, 0.20, 0.20, 0.20],
    "mildly_favorable":   [0.07, 0.13, 0.20, 0.25, 0.35],
    "strongly_favorable": [0.03, 0.07, 0.15, 0.25, 0.50],
}

# =============================================================================
# 4. MODEL BUILDER — p_s argüman olarak alır
# =============================================================================

def build_model(m, p_s,
                e1=None, e3=None, obj="Z2",
                method="augmecon2", r1=1.0, r3=1.0, aug_eps=1e-3):
    x = m.addVars(I, J, S, lb=0, name="x")
    r = m.addVars(I, J, S, lb=0, name="r")
    w = m.addVars(J, K, S, lb=0, name="w")
    y = m.addVars(J, K, S, lb=0, name="y")
    Omega     = m.addVars(K, S, lb=0, ub=1, name="Omega")
    Omega_bar = m.addVars(S,    lb=0, ub=1, name="Obar")
    u         = m.addVars(K, S, lb=0,       name="u")
    z         = m.addVars(J, vtype=GRB.BINARY, name="z")

    s1 = m.addVar(lb=0, name="s1") if (method in ("augmecon", "augmecon2") and e1 is not None) else None
    s3 = m.addVar(lb=0, name="s3") if (method in ("augmecon", "augmecon2") and e3 is not None) else None
    m.update()

    transport_cost = gp.quicksum(
        p_s[s] * (GAMMA + PHI) * (
            gp.quicksum(d_ij[i, j] * x[i, j, s] for i in range(I) for j in range(J)) +
            gp.quicksum(d_jk[j, k] * w[j, k, s] for j in range(J) for k in range(K))
        ) for s in range(S))
    penalty_cost = gp.quicksum(
        p_s[s] * (PI_P + ETA) * (
            gp.quicksum(alpha_ij[i, j] * x[i, j, s] for i in range(I) for j in range(J)) +
            gp.quicksum(beta_jk[j, k]  * w[j, k, s] for j in range(J) for k in range(K))
        ) for s in range(S))
    fixed_cost = gp.quicksum((fc_j[j] + eps_j[j]) * z[j] for j in range(J))

    Z1_expr = transport_cost + penalty_cost + fixed_cost
    Z2_expr = gp.quicksum(p_s[s] * y[j, k, s]
                           for s in range(S) for j in range(J) for k in range(K))
    Z3_expr = gp.quicksum(p_s[s] * u[k, s] for s in range(S) for k in range(K))

    for i in range(I):
        for s in range(S):
            m.addConstr(gp.quicksum(x[i, j, s] for j in range(J)) <= S_is[i, s])
    for i in range(I):
        for j in range(J):
            for s in range(S):
                m.addConstr(r[i, j, s] == (1.0 - alpha_ij[i, j]) * x[i, j, s])
    for j in range(J):
        for s in range(S):
            m.addConstr(gp.quicksum(r[i, j, s] for i in range(I)) ==
                        gp.quicksum(w[j, k, s] for k in range(K)))
            m.addConstr(gp.quicksum(r[i, j, s] for i in range(I)) <= C_j[j] * z[j])
    for j in range(J):
        for k in range(K):
            for s in range(S):
                m.addConstr(y[j, k, s] == (1.0 - beta_jk[j, k]) * w[j, k, s])
    for k in range(K):
        for s in range(S):
            m.addConstr(gp.quicksum(y[j, k, s] for j in range(J)) <= D_ks[k, s])
            m.addConstr(Omega[k, s] * D_ks[k, s] ==
                        gp.quicksum(y[j, k, s] for j in range(J)))
    for s in range(S):
        m.addConstr(Omega_bar[s] * K == gp.quicksum(Omega[k, s] for k in range(K)))
    for k in range(K):
        for s in range(S):
            m.addConstr(u[k, s] >= Omega[k, s] - Omega_bar[s])
            m.addConstr(u[k, s] >= Omega_bar[s] - Omega[k, s])
    for i in range(I):
        for j in range(J):
            for s in range(S):
                m.addConstr(x[i, j, s] <= M_BIG * z[j])
    for j in range(J):
        for k in range(K):
            for s in range(S):
                m.addConstr(y[j, k, s] <= M_BIG * z[j])
    for s in range(S):
        m.addConstr(gp.quicksum(y[j, k, s] for j in range(J) for k in range(K))
                    >= MIN_SERVICE_RATE * total_demand_s[s])

    if method == "epsilon":
        if e1 is not None: m.addConstr(Z1_expr <= e1)
        if e3 is not None: m.addConstr(Z3_expr <= e3)
    else:
        if e1 is not None and s1 is not None:
            m.addConstr(Z1_expr + s1 == e1)
        if e3 is not None and s3 is not None:
            m.addConstr(Z3_expr + s3 == e3)

    if obj == "Z1":
        m.setObjective(Z1_expr, GRB.MINIMIZE)
    elif obj == "Z3":
        m.setObjective(Z3_expr, GRB.MINIMIZE)
    elif method == "epsilon":
        m.setObjective(Z2_expr, GRB.MAXIMIZE)
    elif method == "augmecon2":
        aug = 0.0
        if s1 is not None and r1 > 0:
            aug += aug_eps * (s1 / r1)
        if s3 is not None and r3 > 0:
            aug += aug_eps * 1e-1 * (s3 / r3)
        m.setObjective(Z2_expr + aug, GRB.MAXIMIZE)

    return Z1_expr, Z2_expr, Z3_expr, z, s1, s3


def solve_one(p_s, e1=None, e3=None, obj="Z2",
              method="augmecon2", r1=1.0, r3=1.0, aug_eps=1e-3,
              fixed_objectives=None, time_limit=60):
    m = gp.Model()
    m.setParam("OutputFlag", 0)
    m.setParam("TimeLimit", time_limit)

    Z1_expr, Z2_expr, Z3_expr, z, s1, s3 = build_model(
        m, p_s, e1=e1, e3=e3, obj=obj,
        method=method, r1=r1, r3=r3, aug_eps=aug_eps)

    if fixed_objectives:
        for name, val in fixed_objectives.items():
            tol = max(1e-3, 1e-4 * abs(val))
            if name == "Z1":
                m.addConstr(Z1_expr <= val + tol); m.addConstr(Z1_expr >= val - tol)
            elif name == "Z2":
                m.addConstr(Z2_expr <= val + tol); m.addConstr(Z2_expr >= val - tol)
            elif name == "Z3":
                m.addConstr(Z3_expr <= val + 1e-4); m.addConstr(Z3_expr >= val - 1e-4)

    m.optimize()
    if m.Status not in (GRB.OPTIMAL, GRB.TIME_LIMIT) or m.SolCount == 0:
        m.dispose()
        return None

    res = {
        "Z1": Z1_expr.getValue(),
        "Z2": Z2_expr.getValue(),
        "Z3": Z3_expr.getValue(),
        "z":  {j: round(z[j].X) for j in range(J)},
        "open_dcs": tuple(sorted(dcs[j] for j in range(J) if z[j].X > 0.5)),
        "n_open":   sum(1 for j in range(J) if z[j].X > 0.5),
        "s1": s1.X if s1 is not None else None,
        "s3": s3.X if s3 is not None else None,
    }
    m.dispose()
    return res

# =============================================================================
# 5. PAYOFF + AUGMECON2
# =============================================================================

def compute_payoff(p_s):
    s = solve_one(p_s, obj="Z1", method="epsilon")
    if s is None: return None
    Z1_star = s["Z1"]
    s = solve_one(p_s, obj="Z2", method="epsilon",
                   fixed_objectives={"Z1": Z1_star})
    Z2_at = s["Z2"]
    s = solve_one(p_s, obj="Z3", method="epsilon",
                   fixed_objectives={"Z1": Z1_star, "Z2": Z2_at})
    Z3_at = s["Z3"]
    row1 = {"Z1": Z1_star, "Z2": Z2_at, "Z3": Z3_at}

    s = solve_one(p_s, obj="Z2", method="epsilon")
    Z2_star = s["Z2"]
    s = solve_one(p_s, obj="Z1", method="epsilon",
                   fixed_objectives={"Z2": Z2_star})
    Z1_at = s["Z1"]
    s = solve_one(p_s, obj="Z3", method="epsilon",
                   fixed_objectives={"Z2": Z2_star, "Z1": Z1_at})
    Z3_at = s["Z3"]
    row2 = {"Z1": Z1_at, "Z2": Z2_star, "Z3": Z3_at}

    s = solve_one(p_s, obj="Z3", method="epsilon")
    Z3_star = s["Z3"]
    s = solve_one(p_s, obj="Z1", method="epsilon",
                   fixed_objectives={"Z3": Z3_star})
    Z1_at = s["Z1"]
    s = solve_one(p_s, obj="Z2", method="epsilon",
                   fixed_objectives={"Z3": Z3_star, "Z1": Z1_at})
    Z2_at = s["Z2"]
    row3 = {"Z1": Z1_at, "Z2": Z2_at, "Z3": Z3_star}

    Z1_vals = [row1["Z1"], row2["Z1"], row3["Z1"]]
    Z2_vals = [row1["Z2"], row2["Z2"], row3["Z2"]]
    Z3_vals = [row1["Z3"], row2["Z3"], row3["Z3"]]

    Z1_ideal, Z1_nadir = min(Z1_vals), max(Z1_vals)
    Z2_ideal, Z2_nadir = max(Z2_vals), min(Z2_vals)
    Z3_ideal, Z3_nadir = min(Z3_vals), max(Z3_vals)
    if Z3_nadir - Z3_ideal < 1e-4:
        Z3_nadir = Z3_ideal + 0.5

    return {
        "Z1_ideal": Z1_ideal, "Z1_nadir": Z1_nadir,
        "Z2_ideal": Z2_ideal, "Z2_nadir": Z2_nadir,
        "Z3_ideal": Z3_ideal, "Z3_nadir": Z3_nadir,
        "r1": max(Z1_nadir - Z1_ideal, 1e-6),
        "r3": max(Z3_nadir - Z3_ideal, 1e-6),
    }


def run_augmecon2(p_s, payoff, n1=15, n3=20, aug_eps=1e-3):
    Z1_ideal, Z1_nadir = payoff["Z1_ideal"], payoff["Z1_nadir"]
    Z3_ideal, Z3_nadir = payoff["Z3_ideal"], payoff["Z3_nadir"]
    r1, r3 = payoff["r1"], payoff["r3"]

    e3_vals = np.linspace(Z3_nadir, Z3_ideal, n3)
    e1_vals = np.linspace(Z1_nadir, Z1_ideal, n1)
    step1 = abs(e1_vals[1] - e1_vals[0]) if len(e1_vals) > 1 else 1.0

    solutions = []
    models_solved = 0

    for e3 in e3_vals:
        j1 = 0
        while j1 < len(e1_vals):
            e1 = e1_vals[j1]
            sol = solve_one(p_s, e1=e1, e3=e3, obj="Z2",
                            method="augmecon2",
                            r1=r1, r3=r3, aug_eps=aug_eps)
            models_solved += 1
            if sol:
                sol["e1"] = e1; sol["e3"] = e3
                solutions.append(sol)
                jump = 0
                if sol["s1"] is not None and step1 > 1e-9:
                    jump = max(0, int(sol["s1"] / step1))
                j1 += jump + 1
            else:
                break

    return filter_pareto(solutions), models_solved


def filter_pareto(solutions):
    solutions = [s for s in solutions if s["Z2"] > 1e-3]
    if not solutions: return []
    bucket = {}
    for s in solutions:
        key = (round(s["Z1"], -1), round(s["Z2"]), round(s["Z3"], 2))
        if key not in bucket or s["Z3"] < bucket[key]["Z3"] - 1e-6:
            bucket[key] = s
    unique = list(bucket.values())
    pareto = []
    for i, a in enumerate(unique):
        t1 = max(10.0, 1e-3 * abs(a["Z1"]))
        t2 = max(1.0,  1e-3 * abs(a["Z2"]))
        t3 = max(1e-3, 1e-3 * abs(a["Z3"]))
        dominated = False
        for j_, b in enumerate(unique):
            if i == j_: continue
            if (b["Z1"] <= a["Z1"] + t1 and
                b["Z2"] >= a["Z2"] - t2 and
                b["Z3"] <= a["Z3"] + t3 and
                (b["Z1"] < a["Z1"] - t1 or
                 b["Z2"] > a["Z2"] + t2 or
                 b["Z3"] < a["Z3"] - t3)):
                dominated = True; break
        if not dominated:
            pareto.append(a)
    return pareto

# =============================================================================
# 6. ANA DÖNGÜ
# =============================================================================

def fmt_eta(seconds):
    if seconds < 60: return f"{seconds:.0f}sn"
    if seconds < 3600: return f"{seconds/60:.1f}dk"
    return f"{seconds/3600:.1f}sa"


def run_sensitivity():
    SCHEMES = list(WEIGHT_SCHEMES.keys())

    summary_rows = []
    pareto_rows = []
    dc_freq_rows = []

    t_total = time.time()

    for idx, scheme in enumerate(SCHEMES, 1):
        p_s = WEIGHT_SCHEMES[scheme]

        exp_supply = sum(p_s[s] * total_supply_s[s] for s in range(S))
        exp_demand = sum(p_s[s] * total_demand_s[s] for s in range(S))

        print(f"\n[{idx}/{len(SCHEMES)}] {scheme}", flush=True)
        print(f"  p_s = {[f'{p:.2f}' for p in p_s]}", flush=True)
        print(f"  Beklenen arz = {exp_supply:.0f}, talep = {exp_demand:.0f}, "
              f"oran = {exp_supply/exp_demand:.3f}", flush=True)
        t0 = time.time()

        payoff = compute_payoff(p_s)
        if payoff is None:
            print(f"  HATA: payoff hesaplanamadı.", flush=True)
            continue

        print(f"  Payoff: Z1=[{payoff['Z1_ideal']:,.0f}–{payoff['Z1_nadir']:,.0f}]  "
              f"Z2=[{payoff['Z2_nadir']:,.0f}–{payoff['Z2_ideal']:,.0f}]  "
              f"Z3=[{payoff['Z3_ideal']:.3f}–{payoff['Z3_nadir']:.3f}]", flush=True)

        pareto, n_models = run_augmecon2(p_s, payoff)
        elapsed = time.time() - t0
        print(f"  → {len(pareto)} Pareto noktası | {n_models} model | "
              f"süre: {fmt_eta(elapsed)}", flush=True)

        if not pareto:
            continue

        df_p = pd.DataFrame(pareto)
        idx_minZ1 = df_p["Z1"].idxmin()
        idx_maxZ2 = df_p["Z2"].idxmax()
        idx_minZ3 = df_p["Z3"].idxmin()

        dc_counter = Counter()
        for sol in pareto:
            for d in sol["open_dcs"]:
                dc_counter[d] += 1
        most_common_config = Counter(s["open_dcs"] for s in pareto).most_common(1)[0]

        n_single = sum(1 for s in pareto if s["n_open"] == 1)
        n_double = sum(1 for s in pareto if s["n_open"] == 2)

        summary_rows.append({
            "scheme":        scheme,
            "exp_supply":    exp_supply,
            "exp_demand":    exp_demand,
            "supply_demand_ratio": exp_supply/exp_demand,
            "n_pareto":      len(pareto),
            "Z1_min":        df_p["Z1"].min(),
            "Z1_max":        df_p["Z1"].max(),
            "Z1_mean":       df_p["Z1"].mean(),
            "Z2_min":        df_p["Z2"].min(),
            "Z2_max":        df_p["Z2"].max(),
            "Z2_mean":       df_p["Z2"].mean(),
            "Z3_min":        df_p["Z3"].min(),
            "Z3_max":        df_p["Z3"].max(),
            "Z3_mean":       df_p["Z3"].mean(),
            "minZ1_dcs":     ",".join(pareto[idx_minZ1]["open_dcs"]),
            "maxZ2_dcs":     ",".join(pareto[idx_maxZ2]["open_dcs"]),
            "minZ3_dcs":     ",".join(pareto[idx_minZ3]["open_dcs"]),
            "modal_config":  ",".join(most_common_config[0]),
            "modal_freq":    most_common_config[1],
            "avg_n_open":    np.mean([s["n_open"] for s in pareto]),
            "n_single_dc":   n_single,
            "n_double_dc":   n_double,
            "pct_double":    100*n_double/len(pareto),
            "elapsed_sec":   elapsed,
        })

        for s in pareto:
            pareto_rows.append({
                "scheme":   scheme,
                "Z1": s["Z1"], "Z2": s["Z2"], "Z3": s["Z3"],
                "n_open":   s["n_open"],
                "open_dcs": ",".join(s["open_dcs"]),
            })

        for d in dcs:
            dc_freq_rows.append({
                "scheme":    scheme,
                "dc":        d,
                "freq":      dc_counter.get(d, 0),
                "freq_pct":  100.0 * dc_counter.get(d, 0) / len(pareto),
            })

    total_elapsed = time.time() - t_total
    print(f"\n{'='*72}\nToplam süre: {fmt_eta(total_elapsed)}", flush=True)

    df_summary = pd.DataFrame(summary_rows)
    df_pareto  = pd.DataFrame(pareto_rows)
    df_dcfreq  = pd.DataFrame(dc_freq_rows)

    df_summary.to_csv(os.path.join(DATA_DIR, "prob_sensitivity_summary.csv"), index=False)
    df_pareto.to_csv(os.path.join(DATA_DIR, "prob_sensitivity_pareto.csv"),   index=False)
    df_dcfreq.to_csv(os.path.join(DATA_DIR, "prob_sensitivity_dc_freq.csv"),  index=False)
    print("Kaydedildi: prob_sensitivity_{summary,pareto,dc_freq}.csv", flush=True)

    return df_summary, df_pareto, df_dcfreq

# =============================================================================
# 7. RAPOR + GÖRSELLEŞTİRME
# =============================================================================

def print_report(df_summary):
    print("\n" + "="*108, flush=True)
    print("ÖZET TABLO — Senaryo Olasılık Ağırlıklandırması", flush=True)
    print("="*108, flush=True)
    print(f"{'Yapı':<22} {'arz/talep':>10} {'|PF|':>5} "
          f"{'Z1 ort':>11} {'Z2 ort':>10} {'Z3 ort':>8} "
          f"{'%çift':>7} {'modal':<14}", flush=True)
    print("-"*108, flush=True)
    for _, r in df_summary.iterrows():
        print(f"{r['scheme']:<22} {r['supply_demand_ratio']:>10.3f} "
              f"{int(r['n_pareto']):>5} "
              f"{r['Z1_mean']:>11,.0f} "
              f"{r['Z2_mean']:>10,.0f} {r['Z3_mean']:>8.4f} "
              f"{r['pct_double']:>6.1f}% "
              f"{r['modal_config']:<14}", flush=True)
    print("="*108, flush=True)


def plot_sensitivity(df_summary, df_pareto, df_dcfreq):
    fig = plt.figure(figsize=(16, 11))
    gs = gridspec.GridSpec(2, 2, figure=fig, hspace=0.40, wspace=0.32)

    schemes = ["strongly_adverse", "mildly_adverse", "equal",
               "mildly_favorable", "strongly_favorable"]
    short_names = ["str.adv", "mld.adv", "equal", "mld.fav", "str.fav"]
    colors = plt.cm.RdYlGn(np.linspace(0.10, 0.90, len(schemes)))
    color_map = dict(zip(schemes, colors))

    # Panel 1: Pareto sınırları
    ax1 = fig.add_subplot(gs[0, 0])
    for sc, sn in zip(schemes, short_names):
        sub = df_pareto[df_pareto["scheme"] == sc].sort_values("Z2")
        if len(sub) > 0:
            ax1.plot(sub["Z2"], sub["Z1"]/1e3, "o-",
                     color=color_map[sc], lw=1.8, ms=4,
                     label=sn, alpha=0.85)
    ax1.set_xlabel("Z₂ — Delivered food (kg)", fontsize=10)
    ax1.set_ylabel("Z₁ — Total cost (k$)", fontsize=10)
    ax1.set_title("Pareto Front by Probability Scheme",
                  fontsize=11, fontweight="bold")
    ax1.legend(fontsize=9, loc="best")
    ax1.grid(True, alpha=0.3)

    # Panel 2: Z'lerin baz'a göre % değişimi
    ax2 = fig.add_subplot(gs[0, 1])
    x = np.arange(len(schemes))
    base_Z1 = df_summary[df_summary["scheme"]=="equal"]["Z1_mean"].values[0]
    base_Z2 = df_summary[df_summary["scheme"]=="equal"]["Z2_mean"].values[0]
    base_Z3 = df_summary[df_summary["scheme"]=="equal"]["Z3_mean"].values[0]
    Z1_pcts, Z2_pcts, Z3_pcts = [], [], []
    for sc in schemes:
        r = df_summary[df_summary["scheme"]==sc].iloc[0]
        Z1_pcts.append(100*(r["Z1_mean"]-base_Z1)/base_Z1)
        Z2_pcts.append(100*(r["Z2_mean"]-base_Z2)/base_Z2)
        Z3_pcts.append(100*(r["Z3_mean"]-base_Z3)/base_Z3 if base_Z3 > 1e-6 else 0)
    ax2.axhline(0, color="gray", lw=1.0, alpha=0.5)
    ax2.plot(x, Z1_pcts, "o-", color="#FF6B35", lw=2.5, ms=11, label="Z₁")
    ax2.plot(x, Z2_pcts, "s-", color="#004E89", lw=2.5, ms=11, label="Z₂")
    ax2.plot(x, Z3_pcts, "D-", color="#9D4EDD", lw=2.5, ms=11, label="Z₃")
    ax2.set_xticks(x)
    ax2.set_xticklabels(short_names, rotation=15)
    ax2.set_ylabel("Change vs equal-weight baseline (%)", fontsize=10)
    ax2.set_title("Objective Response to Probability Weighting",
                  fontsize=11, fontweight="bold")
    ax2.legend(fontsize=10)
    ax2.grid(True, alpha=0.3)

    # Panel 3: %çift-DC oranı + ortalama açık DC
    ax3 = fig.add_subplot(gs[1, 0])
    pct_doubles = [df_summary[df_summary["scheme"]==s]["pct_double"].values[0] for s in schemes]
    avg_ndc     = [df_summary[df_summary["scheme"]==s]["avg_n_open"].values[0] for s in schemes]
    bars = ax3.bar(x, pct_doubles, color=[color_map[s] for s in schemes],
                   alpha=0.85, edgecolor="white", lw=1.5)
    for b, v in zip(bars, pct_doubles):
        ax3.text(b.get_x()+b.get_width()/2, b.get_height()+1,
                 f"{v:.0f}%", ha="center", fontsize=10, fontweight="bold")
    ax3.set_xticks(x)
    ax3.set_xticklabels(short_names, rotation=15)
    ax3.set_ylabel("Share of Pareto solutions with 2 DCs (%)", fontsize=10)
    ax3.set_title("Network Size: Single-DC vs. Two-DC Configurations",
                  fontsize=11, fontweight="bold")
    ax3.grid(True, alpha=0.3, axis="y")
    ax3.set_ylim(0, max(pct_doubles)*1.2 if max(pct_doubles)>0 else 10)

    # Panel 4: DC açılma frekansı (heatmap)
    ax4 = fig.add_subplot(gs[1, 1])
    pivot = df_dcfreq.pivot(index="dc", columns="scheme", values="freq_pct")
    pivot = pivot.reindex(dcs)
    pivot = pivot[schemes]  # column sırası
    im = ax4.imshow(pivot.values, cmap="YlOrRd", aspect="auto",
                    vmin=0, vmax=100)
    ax4.set_xticks(range(len(pivot.columns)))
    ax4.set_xticklabels(short_names, rotation=15)
    ax4.set_yticks(range(len(pivot.index)))
    ax4.set_yticklabels(pivot.index)
    ax4.set_ylabel("Distribution Center", fontsize=10)
    ax4.set_title("DC Opening Frequency (% of Pareto solutions)",
                  fontsize=11, fontweight="bold")
    for i in range(len(pivot.index)):
        for jj in range(len(pivot.columns)):
            v = pivot.values[i, jj]
            if not np.isnan(v):
                ax4.text(jj, i, f"{v:.0f}", ha="center", va="center",
                         fontsize=9,
                         color="white" if v > 50 else "black")
    plt.colorbar(im, ax=ax4, fraction=0.04, pad=0.03, label="%")

    fig.suptitle(
        "Sensitivity Analysis — Scenario Probability Weighting\n"
        f"Asymmetric scenarios (S1=adverse → S5=favorable)  ·  Service ≥{int(MIN_SERVICE_RATE*100)}%",
        fontsize=13, fontweight="bold", y=1.00
    )

    out_path = os.path.join(DATA_DIR, "prob_sensitivity.png")
    plt.savefig(out_path, dpi=150, bbox_inches="tight")
    print(f"\nGrafik: {out_path}", flush=True)
    plt.show()

# =============================================================================
# 8. MAIN
# =============================================================================

if __name__ == "__main__":
    df_summary, df_pareto, df_dcfreq = run_sensitivity()
    print_report(df_summary)
    plot_sensitivity(df_summary, df_pareto, df_dcfreq)
    print("\n>>> Tamam.", flush=True)