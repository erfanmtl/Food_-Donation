"""
=============================================================================
 DUYARLILIK ANALİZİ — Bozulma Katsayısı κ(θ)
 -----------------------------------------------------------------------------
 κ baz değeri 0.026077 km⁻¹ (θ=4°C), Arrhenius denkleminden türetilir.
 Bu analizde κ, baz değerin {%60, %80, %100, %120, %140}'ı oranında
 doğrudan ölçeklenir (-40%'dan +40%'a). Her ölçekte AUGMECON2 ile tüm
 Pareto sınırı yeniden hesaplanır.

 Ek olarak iki rota metriği hesaplanır:
   - Akış-ağırlıklı ortalama donor→DC mesafesi (km)
   - Aktif donor-DC bağlantı sayısı (x_ij^s > 0)
 Bu metrikler, "model yüksek bozulmada daha kısa/daha sık rotalara kayar"
 hipotezini ampirik olarak test eder.

 Çıktılar:
   - kappa_sensitivity_summary.csv
   - kappa_sensitivity_pareto.csv
   - kappa_sensitivity_dc_freq.csv
   - kappa_sensitivity.png  (4 panelli: Pareto, Z2 etkisi, rota metrikleri,
                              DC frekans heatmap)
=============================================================================
"""

import os
import sys
import time
from collections import Counter
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import gurobipy as gp
from gurobipy import GRB

sys.stdout.reconfigure(line_buffering=True)

# =============================================================================
# 0. VERİ YÜKLEME
# =============================================================================

DATA_DIR = os.path.dirname(os.path.abspath(__file__))

donors_df   = pd.read_csv(os.path.join(DATA_DIR, "donors.csv"))
dc_df       = pd.read_csv(os.path.join(DATA_DIR, "distribution_centers.csv"))
charity_df  = pd.read_csv(os.path.join(DATA_DIR, "charities.csv"))
scenario_df = pd.read_csv(os.path.join(DATA_DIR, "scenarios.csv"))
dist_df     = pd.read_csv(os.path.join(DATA_DIR, "distance_matrix.csv"))

donors    = donors_df["donor_id"].tolist()
dcs       = dc_df["dc_id"].tolist()
charities = charity_df["charity_id"].tolist()
I, J, K, S = len(donors), len(dcs), len(charities), len(scenario_df)

p_s = [1.0 / S] * S
supply_base = donors_df.set_index("donor_id")["avg_daily_surplus_kg"]
demand_base = charity_df.set_index("charity_id")["avg_daily_demand_kg"]
supply_mult = scenario_df["donor_supply_multiplier"].values
demand_mult = scenario_df["demand_multiplier"].values

S_is = {(i, s): float(supply_base[donors[i]]) * float(supply_mult[s])
        for i in range(I) for s in range(S)}
D_ks = {(k, s): float(demand_base[charities[k]]) * float(demand_mult[s])
        for k in range(K) for s in range(S)}

C_j  = {j: float(dc_df.iloc[j]["capacity_kg"]) for j in range(J)}
fc_j = {j: float(dc_df.iloc[j]["fixed_cost"])  for j in range(J)}
refrig_cost_map = {"high": 1400.0, "medium": 1000.0, "low": 600.0}
eps_j = {j: refrig_cost_map.get(dc_df.iloc[j]["refrigeration_level"], 1000.0)
         for j in range(J)}

# Baz κ
kappa0_base, theta_T, eps_ac, R_gas = 0.05, 4.0, 1500.0, 8.314
KAPPA_BASE = kappa0_base * np.exp(-eps_ac / (R_gas * (theta_T + 273.15)))
print(f"Baz κ(θ=4°C) = {KAPPA_BASE:.6f} km⁻¹", flush=True)

max_shelf = donors_df["shelf_life_hours"].max()
L_i = {did: 0.5 + 0.5 * (
        float(donors_df.loc[donors_df["donor_id"] == did,
                            "shelf_life_hours"].values[0]) / max_shelf)
       for did in donors}

dist_lookup = dist_df.set_index(["origin_id", "destination_id"])["distance_km"].to_dict()
def get_dist(o, d):
    v = dist_lookup.get((o, d))
    if v is not None: return float(v)
    v = dist_lookup.get((d, o))
    return float(v) if v is not None else 9999.0

d_ij = {(i, j): get_dist(donors[i], dcs[j])    for i in range(I) for j in range(J)}
d_jk = {(j, k): get_dist(dcs[j], charities[k]) for j in range(J) for k in range(K)}

# Sabit baz değerler
GAMMA  = 0.05
PHI    = 0.03
PI_P   = 2.0
ETA    = 0.08
M_BIG  = max(S_is.values()) * I * 1.5
MIN_SERVICE_RATE = 0.30
total_demand_s = {s: sum(D_ks[k, s] for k in range(K)) for s in range(S)}

# =============================================================================
# 1. κ-bağımlı α/β hesaplayıcı
# =============================================================================

def compute_alpha_beta(kappa_val):
    """Verilen κ için α_ij ve β_jk matrislerini hesapla."""
    alpha = {}
    beta = {}
    for i in range(I):
        for j in range(J):
            v = 1.0 - L_i[donors[i]] * np.exp(-kappa_val * d_ij[i, j])
            alpha[i, j] = min(max(v, 0.0), 0.99)
    for j in range(J):
        for k in range(K):
            v = 1.0 - np.exp(-kappa_val * d_jk[j, k])
            beta[j, k] = min(max(v, 0.0), 0.99)
    return alpha, beta

# =============================================================================
# 2. MODEL BUILDER — α, β'yi argüman olarak alır
# =============================================================================

def build_model(m, alpha_ij, beta_jk,
                e1=None, e3=None, obj="Z2",
                method="augmecon2", r1=1.0, r3=1.0, aug_eps=1e-3):
    x = m.addVars(I, J, S, lb=0, name="x")
    r = m.addVars(I, J, S, lb=0, name="r")
    w = m.addVars(J, K, S, lb=0, name="w")
    y = m.addVars(J, K, S, lb=0, name="y")
    Omega     = m.addVars(K, S, lb=0, ub=1, name="Omega")
    Omega_bar = m.addVars(S,    lb=0, ub=1, name="Obar")
    u         = m.addVars(K, S, lb=0,       name="u")
    z         = m.addVars(J, vtype=GRB.BINARY, name="z")

    s1 = m.addVar(lb=0, name="s1") if (method in ("augmecon", "augmecon2") and e1 is not None) else None
    s3 = m.addVar(lb=0, name="s3") if (method in ("augmecon", "augmecon2") and e3 is not None) else None
    m.update()

    transport_cost = gp.quicksum(
        p_s[s] * (GAMMA + PHI) * (
            gp.quicksum(d_ij[i, j] * x[i, j, s] for i in range(I) for j in range(J)) +
            gp.quicksum(d_jk[j, k] * w[j, k, s] for j in range(J) for k in range(K))
        ) for s in range(S))
    penalty_cost = gp.quicksum(
        p_s[s] * (PI_P + ETA) * (
            gp.quicksum(alpha_ij[i, j] * x[i, j, s] for i in range(I) for j in range(J)) +
            gp.quicksum(beta_jk[j, k]  * w[j, k, s] for j in range(J) for k in range(K))
        ) for s in range(S))
    fixed_cost = gp.quicksum((fc_j[j] + eps_j[j]) * z[j] for j in range(J))

    Z1_expr = transport_cost + penalty_cost + fixed_cost
    Z2_expr = gp.quicksum(p_s[s] * y[j, k, s]
                           for s in range(S) for j in range(J) for k in range(K))
    Z3_expr = gp.quicksum(p_s[s] * u[k, s] for s in range(S) for k in range(K))

    for i in range(I):
        for s in range(S):
            m.addConstr(gp.quicksum(x[i, j, s] for j in range(J)) <= S_is[i, s])
    for i in range(I):
        for j in range(J):
            for s in range(S):
                m.addConstr(r[i, j, s] == (1.0 - alpha_ij[i, j]) * x[i, j, s])
    for j in range(J):
        for s in range(S):
            m.addConstr(gp.quicksum(r[i, j, s] for i in range(I)) ==
                        gp.quicksum(w[j, k, s] for k in range(K)))
            m.addConstr(gp.quicksum(r[i, j, s] for i in range(I)) <= C_j[j] * z[j])
    for j in range(J):
        for k in range(K):
            for s in range(S):
                m.addConstr(y[j, k, s] == (1.0 - beta_jk[j, k]) * w[j, k, s])
    for k in range(K):
        for s in range(S):
            m.addConstr(gp.quicksum(y[j, k, s] for j in range(J)) <= D_ks[k, s])
            m.addConstr(Omega[k, s] * D_ks[k, s] ==
                        gp.quicksum(y[j, k, s] for j in range(J)))
    for s in range(S):
        m.addConstr(Omega_bar[s] * K == gp.quicksum(Omega[k, s] for k in range(K)))
    for k in range(K):
        for s in range(S):
            m.addConstr(u[k, s] >= Omega[k, s] - Omega_bar[s])
            m.addConstr(u[k, s] >= Omega_bar[s] - Omega[k, s])
    for i in range(I):
        for j in range(J):
            for s in range(S):
                m.addConstr(x[i, j, s] <= M_BIG * z[j])
    for j in range(J):
        for k in range(K):
            for s in range(S):
                m.addConstr(y[j, k, s] <= M_BIG * z[j])
    for s in range(S):
        m.addConstr(gp.quicksum(y[j, k, s] for j in range(J) for k in range(K))
                    >= MIN_SERVICE_RATE * total_demand_s[s])

    if method == "epsilon":
        if e1 is not None: m.addConstr(Z1_expr <= e1)
        if e3 is not None: m.addConstr(Z3_expr <= e3)
    else:
        if e1 is not None and s1 is not None:
            m.addConstr(Z1_expr + s1 == e1)
        if e3 is not None and s3 is not None:
            m.addConstr(Z3_expr + s3 == e3)

    if obj == "Z1":
        m.setObjective(Z1_expr, GRB.MINIMIZE)
    elif obj == "Z3":
        m.setObjective(Z3_expr, GRB.MINIMIZE)
    elif method == "epsilon":
        m.setObjective(Z2_expr, GRB.MAXIMIZE)
    elif method == "augmecon2":
        aug = 0.0
        if s1 is not None and r1 > 0:
            aug += aug_eps * (s1 / r1)
        if s3 is not None and r3 > 0:
            aug += aug_eps * 1e-1 * (s3 / r3)
        m.setObjective(Z2_expr + aug, GRB.MAXIMIZE)

    return Z1_expr, Z2_expr, Z3_expr, z, x, w, s1, s3


def solve_one(alpha_ij, beta_jk,
              e1=None, e3=None, obj="Z2",
              method="augmecon2", r1=1.0, r3=1.0, aug_eps=1e-3,
              fixed_objectives=None, time_limit=60):
    m = gp.Model()
    m.setParam("OutputFlag", 0)
    m.setParam("TimeLimit", time_limit)

    Z1_expr, Z2_expr, Z3_expr, z, x, w, s1, s3 = build_model(
        m, alpha_ij, beta_jk, e1=e1, e3=e3, obj=obj,
        method=method, r1=r1, r3=r3, aug_eps=aug_eps)

    if fixed_objectives:
        for name, val in fixed_objectives.items():
            tol = max(1e-3, 1e-4 * abs(val))
            if name == "Z1":
                m.addConstr(Z1_expr <= val + tol); m.addConstr(Z1_expr >= val - tol)
            elif name == "Z2":
                m.addConstr(Z2_expr <= val + tol); m.addConstr(Z2_expr >= val - tol)
            elif name == "Z3":
                m.addConstr(Z3_expr <= val + 1e-4); m.addConstr(Z3_expr >= val - 1e-4)

    m.optimize()
    if m.Status not in (GRB.OPTIMAL, GRB.TIME_LIMIT) or m.SolCount == 0:
        m.dispose()
        return None

    # x ve w'den rota metriklerini çek (akış-ağırlıklı)
    total_x_flow = 0.0
    total_x_dist_flow = 0.0
    n_active_links = 0
    for i in range(I):
        for j in range(J):
            for s in range(S):
                xv = x[i, j, s].X
                if xv > 1e-3:
                    total_x_flow += p_s[s] * xv
                    total_x_dist_flow += p_s[s] * xv * d_ij[i, j]
    # Aktif bağlantı: senaryo-ortalama bazda hangi (i,j) çiftleri kullanılmış?
    active_pairs = set()
    for i in range(I):
        for j in range(J):
            for s in range(S):
                if x[i, j, s].X > 1e-3:
                    active_pairs.add((i, j))
                    break
    n_active_links = len(active_pairs)
    avg_donor_dc_dist = (total_x_dist_flow / total_x_flow) if total_x_flow > 1e-6 else 0.0

    res = {
        "Z1": Z1_expr.getValue(),
        "Z2": Z2_expr.getValue(),
        "Z3": Z3_expr.getValue(),
        "z":  {j: round(z[j].X) for j in range(J)},
        "open_dcs": tuple(sorted(dcs[j] for j in range(J) if z[j].X > 0.5)),
        "n_open":   sum(1 for j in range(J) if z[j].X > 0.5),
        "avg_donor_dc_dist": avg_donor_dc_dist,
        "n_active_links":    n_active_links,
        "s1": s1.X if s1 is not None else None,
        "s3": s3.X if s3 is not None else None,
    }
    m.dispose()
    return res

# =============================================================================
# 3. PAYOFF (her κ için yeniden)
# =============================================================================

def compute_payoff(alpha_ij, beta_jk):
    s = solve_one(alpha_ij, beta_jk, obj="Z1", method="epsilon")
    if s is None: return None
    Z1_star = s["Z1"]
    s = solve_one(alpha_ij, beta_jk, obj="Z2", method="epsilon",
                   fixed_objectives={"Z1": Z1_star})
    Z2_at = s["Z2"]
    s = solve_one(alpha_ij, beta_jk, obj="Z3", method="epsilon",
                   fixed_objectives={"Z1": Z1_star, "Z2": Z2_at})
    Z3_at = s["Z3"]
    row1 = {"Z1": Z1_star, "Z2": Z2_at, "Z3": Z3_at}

    s = solve_one(alpha_ij, beta_jk, obj="Z2", method="epsilon")
    Z2_star = s["Z2"]
    s = solve_one(alpha_ij, beta_jk, obj="Z1", method="epsilon",
                   fixed_objectives={"Z2": Z2_star})
    Z1_at = s["Z1"]
    s = solve_one(alpha_ij, beta_jk, obj="Z3", method="epsilon",
                   fixed_objectives={"Z2": Z2_star, "Z1": Z1_at})
    Z3_at = s["Z3"]
    row2 = {"Z1": Z1_at, "Z2": Z2_star, "Z3": Z3_at}

    s = solve_one(alpha_ij, beta_jk, obj="Z3", method="epsilon")
    Z3_star = s["Z3"]
    s = solve_one(alpha_ij, beta_jk, obj="Z1", method="epsilon",
                   fixed_objectives={"Z3": Z3_star})
    Z1_at = s["Z1"]
    s = solve_one(alpha_ij, beta_jk, obj="Z2", method="epsilon",
                   fixed_objectives={"Z3": Z3_star, "Z1": Z1_at})
    Z2_at = s["Z2"]
    row3 = {"Z1": Z1_at, "Z2": Z2_at, "Z3": Z3_star}

    Z1_vals = [row1["Z1"], row2["Z1"], row3["Z1"]]
    Z2_vals = [row1["Z2"], row2["Z2"], row3["Z2"]]
    Z3_vals = [row1["Z3"], row2["Z3"], row3["Z3"]]

    Z1_ideal, Z1_nadir = min(Z1_vals), max(Z1_vals)
    Z2_ideal, Z2_nadir = max(Z2_vals), min(Z2_vals)
    Z3_ideal, Z3_nadir = min(Z3_vals), max(Z3_vals)
    if Z3_nadir - Z3_ideal < 1e-4:
        Z3_nadir = Z3_ideal + 0.5

    return {
        "Z1_ideal": Z1_ideal, "Z1_nadir": Z1_nadir,
        "Z2_ideal": Z2_ideal, "Z2_nadir": Z2_nadir,
        "Z3_ideal": Z3_ideal, "Z3_nadir": Z3_nadir,
        "r1": max(Z1_nadir - Z1_ideal, 1e-6),
        "r3": max(Z3_nadir - Z3_ideal, 1e-6),
    }

# =============================================================================
# 4. AUGMECON2
# =============================================================================

def run_augmecon2(alpha_ij, beta_jk, payoff, n1=15, n3=20, aug_eps=1e-3):
    Z1_ideal, Z1_nadir = payoff["Z1_ideal"], payoff["Z1_nadir"]
    Z3_ideal, Z3_nadir = payoff["Z3_ideal"], payoff["Z3_nadir"]
    r1, r3 = payoff["r1"], payoff["r3"]

    e3_vals = np.linspace(Z3_nadir, Z3_ideal, n3)
    e1_vals = np.linspace(Z1_nadir, Z1_ideal, n1)
    step1 = abs(e1_vals[1] - e1_vals[0]) if len(e1_vals) > 1 else 1.0

    solutions = []
    models_solved = 0

    for e3 in e3_vals:
        j1 = 0
        while j1 < len(e1_vals):
            e1 = e1_vals[j1]
            sol = solve_one(alpha_ij, beta_jk, e1=e1, e3=e3,
                            obj="Z2", method="augmecon2",
                            r1=r1, r3=r3, aug_eps=aug_eps)
            models_solved += 1
            if sol:
                sol["e1"] = e1; sol["e3"] = e3
                solutions.append(sol)
                jump = 0
                if sol["s1"] is not None and step1 > 1e-9:
                    jump = max(0, int(sol["s1"] / step1))
                j1 += jump + 1
            else:
                break

    return filter_pareto(solutions), models_solved


def filter_pareto(solutions):
    solutions = [s for s in solutions if s["Z2"] > 1e-3]
    if not solutions: return []

    bucket = {}
    for s in solutions:
        key = (round(s["Z1"], -1), round(s["Z2"]), round(s["Z3"], 2))
        if key not in bucket or s["Z3"] < bucket[key]["Z3"] - 1e-6:
            bucket[key] = s
    unique = list(bucket.values())

    pareto = []
    for i, a in enumerate(unique):
        t1 = max(10.0, 1e-3 * abs(a["Z1"]))
        t2 = max(1.0,  1e-3 * abs(a["Z2"]))
        t3 = max(1e-3, 1e-3 * abs(a["Z3"]))
        dominated = False
        for j_, b in enumerate(unique):
            if i == j_: continue
            if (b["Z1"] <= a["Z1"] + t1 and
                b["Z2"] >= a["Z2"] - t2 and
                b["Z3"] <= a["Z3"] + t3 and
                (b["Z1"] < a["Z1"] - t1 or
                 b["Z2"] > a["Z2"] + t2 or
                 b["Z3"] < a["Z3"] - t3)):
                dominated = True; break
        if not dominated:
            pareto.append(a)
    return pareto

# =============================================================================
# 5. ANA DUYARLILIK DÖNGÜSÜ
# =============================================================================

def fmt_eta(seconds):
    if seconds < 60: return f"{seconds:.0f}sn"
    if seconds < 3600: return f"{seconds/60:.1f}dk"
    return f"{seconds/3600:.1f}sa"


def run_sensitivity():
    SCALES = [0.60, 0.80, 1.00, 1.20, 1.40]

    print("="*72, flush=True)
    print(" DUYARLILIK ANALİZİ — Bozulma Katsayısı κ(θ)", flush=True)
    print(f" Baz κ = {KAPPA_BASE:.6f} km⁻¹", flush=True)
    print(f" Ölçekler: {SCALES} → κ ∈ [{KAPPA_BASE*0.6:.5f}, {KAPPA_BASE*1.4:.5f}]",
          flush=True)
    print("="*72, flush=True)

    summary_rows = []
    pareto_rows = []
    dc_freq_rows = []

    t_total = time.time()

    for idx, scale in enumerate(SCALES, 1):
        kappa_val = KAPPA_BASE * scale
        alpha_ij, beta_jk = compute_alpha_beta(kappa_val)

        # Ortalama α/β değerleri (içgörü için)
        avg_alpha = np.mean(list(alpha_ij.values()))
        avg_beta  = np.mean(list(beta_jk.values()))

        print(f"\n[{idx}/{len(SCALES)}] Ölçek = %{scale*100:.0f}  "
              f"(κ={kappa_val:.5f})", flush=True)
        print(f"  Ortalama α={avg_alpha:.3f}, β={avg_beta:.3f}", flush=True)
        t0 = time.time()

        payoff = compute_payoff(alpha_ij, beta_jk)
        if payoff is None:
            print(f"  HATA: payoff hesaplanamadı.", flush=True)
            continue

        print(f"  Payoff: Z1=[{payoff['Z1_ideal']:,.0f}–{payoff['Z1_nadir']:,.0f}]  "
              f"Z2=[{payoff['Z2_nadir']:,.0f}–{payoff['Z2_ideal']:,.0f}]  "
              f"Z3=[{payoff['Z3_ideal']:.3f}–{payoff['Z3_nadir']:.3f}]", flush=True)

        pareto, n_models = run_augmecon2(alpha_ij, beta_jk, payoff)
        elapsed = time.time() - t0
        print(f"  → {len(pareto)} Pareto noktası | {n_models} model | "
              f"süre: {fmt_eta(elapsed)}", flush=True)

        if not pareto:
            continue

        df_p = pd.DataFrame(pareto)

        idx_minZ1 = df_p["Z1"].idxmin()
        idx_maxZ2 = df_p["Z2"].idxmax()
        idx_minZ3 = df_p["Z3"].idxmin()

        dc_counter = Counter()
        for sol in pareto:
            for d in sol["open_dcs"]:
                dc_counter[d] += 1
        most_common_config = Counter(s["open_dcs"] for s in pareto).most_common(1)[0]

        summary_rows.append({
            "scale_pct":   int(scale * 100),
            "kappa":       kappa_val,
            "avg_alpha":   avg_alpha,
            "avg_beta":    avg_beta,
            "n_pareto":    len(pareto),
            "Z1_min":      df_p["Z1"].min(),
            "Z1_max":      df_p["Z1"].max(),
            "Z1_mean":     df_p["Z1"].mean(),
            "Z2_min":      df_p["Z2"].min(),
            "Z2_max":      df_p["Z2"].max(),
            "Z2_mean":     df_p["Z2"].mean(),
            "Z3_min":      df_p["Z3"].min(),
            "Z3_max":      df_p["Z3"].max(),
            "Z3_mean":     df_p["Z3"].mean(),
            "avg_donor_dc_dist_mean": df_p["avg_donor_dc_dist"].mean(),
            "n_active_links_mean":   df_p["n_active_links"].mean(),
            "minZ1_dcs":   ",".join(pareto[idx_minZ1]["open_dcs"]),
            "maxZ2_dcs":   ",".join(pareto[idx_maxZ2]["open_dcs"]),
            "minZ3_dcs":   ",".join(pareto[idx_minZ3]["open_dcs"]),
            "modal_config":",".join(most_common_config[0]),
            "modal_freq":  most_common_config[1],
            "avg_n_open":  np.mean([s["n_open"] for s in pareto]),
            "elapsed_sec": elapsed,
        })

        for s in pareto:
            pareto_rows.append({
                "scale_pct":  int(scale * 100),
                "kappa":      kappa_val,
                "Z1": s["Z1"], "Z2": s["Z2"], "Z3": s["Z3"],
                "n_open":     s["n_open"],
                "open_dcs":   ",".join(s["open_dcs"]),
                "avg_donor_dc_dist": s["avg_donor_dc_dist"],
                "n_active_links":    s["n_active_links"],
            })

        for d in dcs:
            dc_freq_rows.append({
                "scale_pct": int(scale * 100),
                "kappa":     kappa_val,
                "dc":        d,
                "freq":      dc_counter.get(d, 0),
                "freq_pct":  100.0 * dc_counter.get(d, 0) / len(pareto),
            })

    total_elapsed = time.time() - t_total
    print(f"\n{'='*72}\nToplam süre: {fmt_eta(total_elapsed)}", flush=True)

    df_summary = pd.DataFrame(summary_rows)
    df_pareto  = pd.DataFrame(pareto_rows)
    df_dcfreq  = pd.DataFrame(dc_freq_rows)

    df_summary.to_csv(os.path.join(DATA_DIR, "kappa_sensitivity_summary.csv"), index=False)
    df_pareto.to_csv(os.path.join(DATA_DIR, "kappa_sensitivity_pareto.csv"),   index=False)
    df_dcfreq.to_csv(os.path.join(DATA_DIR, "kappa_sensitivity_dc_freq.csv"),  index=False)
    print("Kaydedildi: kappa_sensitivity_{summary,pareto,dc_freq}.csv", flush=True)

    return df_summary, df_pareto, df_dcfreq

# =============================================================================
# 6. RAPOR + GÖRSELLEŞTİRME
# =============================================================================

def print_report(df_summary):
    print("\n" + "="*100, flush=True)
    print("ÖZET TABLO — κ(θ) Duyarlılık Analizi", flush=True)
    print("="*100, flush=True)
    print(f"{'Ölçek':>6} {'κ':>9} {'avg α':>6} {'avg β':>6} {'|PF|':>5} "
          f"{'Z2 ort':>10} {'ΔZ2%':>7} {'Z1 ort':>11} "
          f"{'rota km':>8} {'akt link':>9} {'modal':<14}", flush=True)
    print("-"*100, flush=True)

    base_Z2 = df_summary.loc[df_summary["scale_pct"] == 100, "Z2_mean"].values
    base_Z2 = base_Z2[0] if len(base_Z2) else df_summary["Z2_mean"].iloc[0]

    for _, r in df_summary.iterrows():
        delta_Z2 = 100 * (r["Z2_mean"] - base_Z2) / base_Z2
        print(f"%{r['scale_pct']:>4} {r['kappa']:>9.5f} "
              f"{r['avg_alpha']:>6.3f} {r['avg_beta']:>6.3f} "
              f"{int(r['n_pareto']):>5} "
              f"{r['Z2_mean']:>10,.0f} {delta_Z2:>+6.1f}% "
              f"{r['Z1_mean']:>11,.0f} "
              f"{r['avg_donor_dc_dist_mean']:>8.1f} "
              f"{r['n_active_links_mean']:>9.2f} "
              f"{r['modal_config']:<14}", flush=True)
    print("="*100, flush=True)


def plot_sensitivity(df_summary, df_pareto, df_dcfreq):
    fig = plt.figure(figsize=(16, 11))
    gs = gridspec.GridSpec(2, 2, figure=fig, hspace=0.35, wspace=0.30)

    scales = sorted(df_summary["scale_pct"].unique())
    cmap = plt.cm.coolwarm(np.linspace(0.10, 0.90, len(scales)))
    color_map = dict(zip(scales, cmap))

    # Panel 1: Pareto sınırları (Z2 vs Z1) — κ etkisi en net görünüyor
    ax1 = fig.add_subplot(gs[0, 0])
    for sc in scales:
        sub = df_pareto[df_pareto["scale_pct"] == sc].sort_values("Z2")
        ax1.plot(sub["Z2"], sub["Z1"]/1e3, "o-",
                 color=color_map[sc], lw=1.8, ms=4,
                 label=f"%{sc} (κ×{sc/100:.1f})", alpha=0.85)
    ax1.set_xlabel("Z₂ — Teslim edilen gıda (kg)", fontsize=10)
    ax1.set_ylabel("Z₁ — Toplam maliyet (k$)", fontsize=10)
    ax1.set_title("Pareto Sınırı: κ Ölçeğine Göre Z₁–Z₂",
                  fontsize=11, fontweight="bold")
    ax1.legend(title="κ ölçeği", fontsize=8, loc="best")
    ax1.grid(True, alpha=0.3)

    # Panel 2: Z2 ortalama ve aralık vs ölçek (BU ANALİZİN ANA BULGUSU)
    ax2 = fig.add_subplot(gs[0, 1])
    ax2.plot(df_summary["scale_pct"], df_summary["Z2_mean"],
             "o-", color="#2E7D32", lw=2.5, ms=10, label="Z₂ ort")
    ax2.fill_between(df_summary["scale_pct"],
                     df_summary["Z2_min"],
                     df_summary["Z2_max"],
                     color="#2E7D32", alpha=0.18, label="Z₂ aralık")
    # Etiketler
    base_Z2 = df_summary.loc[df_summary["scale_pct"]==100,"Z2_mean"].values[0]
    for _, r in df_summary.iterrows():
        delta = 100*(r["Z2_mean"]-base_Z2)/base_Z2
        ax2.annotate(f"{delta:+.1f}%", (r["scale_pct"], r["Z2_mean"]),
                     textcoords="offset points", xytext=(0, 10),
                     ha="center", fontsize=9, fontweight="bold",
                     color="#2E7D32")
    ax2.set_xlabel("κ ölçeği (% baz)", fontsize=10)
    ax2.set_ylabel("Z₂ — Beslenme verimi (kg)", fontsize=10)
    ax2.set_title("Z₂'nin κ'ye Tepkisi — Bozulma Arttıkça Verim Düşer",
                  fontsize=11, fontweight="bold")
    ax2.legend(fontsize=9); ax2.grid(True, alpha=0.3)
    ax2.axvline(100, color="gray", lw=0.8, ls="--", alpha=0.6)

    # Panel 3: Rota metrikleri — kısa rotaya kayma hipotezi testi
    ax3 = fig.add_subplot(gs[1, 0])
    ln1 = ax3.plot(df_summary["scale_pct"], df_summary["avg_donor_dc_dist_mean"],
                   "s-", color="#1565C0", lw=2.5, ms=10,
                   label="Ort. donor→DC mesafesi")
    ax3.set_xlabel("κ ölçeği (% baz)", fontsize=10)
    ax3.set_ylabel("Ortalama donor→DC mesafesi (km)",
                   color="#1565C0", fontsize=10)
    ax3.tick_params(axis="y", labelcolor="#1565C0")
    ax3.grid(True, alpha=0.3)
    ax3b = ax3.twinx()
    ln2 = ax3b.plot(df_summary["scale_pct"], df_summary["n_active_links_mean"],
                    "D-", color="#E65100", lw=2.5, ms=10,
                    label="Ort. aktif (i,j) bağlantı sayısı")
    ax3b.set_ylabel("Aktif donor-DC bağlantı sayısı",
                    color="#E65100", fontsize=10)
    ax3b.tick_params(axis="y", labelcolor="#E65100")
    ax3.set_title("Rota Yapısı: Kısa-ve-Sık Rota Hipotezi",
                  fontsize=11, fontweight="bold")
    lns = ln1 + ln2
    ax3.legend(lns, [l.get_label() for l in lns], fontsize=9, loc="best")
    ax3.axvline(100, color="gray", lw=0.8, ls="--", alpha=0.6)

    # Panel 4: DC açılma frekansı (heatmap)
    ax4 = fig.add_subplot(gs[1, 1])
    pivot = df_dcfreq.pivot(index="dc", columns="scale_pct", values="freq_pct")
    pivot = pivot.reindex(dcs)
    im = ax4.imshow(pivot.values, cmap="YlOrRd", aspect="auto",
                    vmin=0, vmax=100)
    ax4.set_xticks(range(len(pivot.columns)))
    ax4.set_xticklabels([f"%{c}" for c in pivot.columns])
    ax4.set_yticks(range(len(pivot.index)))
    ax4.set_yticklabels(pivot.index)
    ax4.set_xlabel("κ ölçeği", fontsize=10)
    ax4.set_ylabel("Dağıtım Merkezi", fontsize=10)
    ax4.set_title("DC Açılma Frekansı (% Pareto noktası)",
                  fontsize=11, fontweight="bold")
    for i in range(len(pivot.index)):
        for jj in range(len(pivot.columns)):
            v = pivot.values[i, jj]
            if not np.isnan(v):
                ax4.text(jj, i, f"{v:.0f}", ha="center", va="center",
                         fontsize=8,
                         color="white" if v > 50 else "black")
    plt.colorbar(im, ax=ax4, fraction=0.04, pad=0.03, label="%")

    fig.suptitle(
        f"Duyarlılık Analizi — Bozulma Katsayısı κ(θ)\n"
        f"Baz: κ={KAPPA_BASE:.5f} km⁻¹ (θ=4°C)  ·  Hizmet ≥%{int(MIN_SERVICE_RATE*100)}",
        fontsize=13, fontweight="bold", y=1.00
    )

    out_path = os.path.join(DATA_DIR, "kappa_sensitivity.png")
    plt.savefig(out_path, dpi=150, bbox_inches="tight")
    print(f"\nGrafik: {out_path}", flush=True)
    plt.show()

# =============================================================================
# 7. MAIN
# =============================================================================

if __name__ == "__main__":
    df_summary, df_pareto, df_dcfreq = run_sensitivity()
    print_report(df_summary)
    plot_sensitivity(df_summary, df_pareto, df_dcfreq)
    print("\n>>> Tamam.", flush=True)