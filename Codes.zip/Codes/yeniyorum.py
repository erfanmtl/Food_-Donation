
import os
import sys
import time
import math
import pandas as pd
import numpy as np
import gurobipy as gp
from gurobipy import GRB

sys.stdout.reconfigure(line_buffering=True)

# =============================================================================
# KONFİGÜRASYON
# =============================================================================
RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

INSTANCES = {
    "medium": {"n_donor": 100, "n_dc": 5,  "n_charity": 20, "n1": 15, "n3": 20},
    "large":  {"n_donor": 150, "n_dc": 7,  "n_charity": 30, "n1": 15, "n3": 20},
    "xlarge": {"n_donor": 200, "n_dc": 10, "n_charity": 40, "n1": 15, "n3": 20},
}

LAT_MIN, LAT_MAX = 40.93, 41.09
LON_MIN, LON_MAX = 28.89, 29.05
TIME_PER_KM = 1.715

# =============================================================================
# VERİ ÜRETİM FONKSİYONLARI
# =============================================================================

def haversine_km(lat1, lon1, lat2, lon2):
    R = 6371
    lat1_r, lat2_r = math.radians(lat1), math.radians(lat2)
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat/2)**2 + math.cos(lat1_r)*math.cos(lat2_r)*math.sin(dlon/2)**2
    return 2 * R * math.asin(math.sqrt(a))


def generate_donors(n_total, base_df):
    existing = base_df.copy()
    n_existing = len(existing)
    n_new = n_total - n_existing
    if n_new <= 0:
        return existing.iloc[:n_total].reset_index(drop=True)
    donor_types = existing["donor_type"].values
    food_types = existing["food_type"].values
    shelf_lives = existing["shelf_life_hours"].values
    s_mean, s_std = existing["avg_daily_surplus_kg"].mean(), existing["avg_daily_surplus_kg"].std()
    s_min, s_max = existing["avg_daily_surplus_kg"].min(), existing["avg_daily_surplus_kg"].max()
    st_mean, st_std = existing["std_surplus"].mean(), existing["std_surplus"].std()
    st_min, st_max = existing["std_surplus"].min(), existing["std_surplus"].max()
    lats = np.random.uniform(LAT_MIN, LAT_MAX, n_new)
    lons = np.random.uniform(LON_MIN, LON_MAX, n_new)
    recs = []
    for k in range(n_new):
        recs.append({
            "donor_id": f"D{n_existing+k+1}",
            "latitude": lats[k], "longitude": lons[k],
            "donor_type": np.random.choice(donor_types),
            "avg_daily_surplus_kg": int(np.clip(np.random.normal(s_mean, s_std), s_min, s_max)),
            "std_surplus": int(np.clip(np.random.normal(st_mean, st_std), st_min, st_max)),
            "food_type": np.random.choice(food_types),
            "shelf_life_hours": int(np.random.choice(shelf_lives)),
        })
    return pd.concat([existing, pd.DataFrame(recs)], ignore_index=True)


def generate_dcs(n_total, base_df):
    existing = base_df.copy()
    n_existing = len(existing)
    n_new = n_total - n_existing
    if n_new <= 0:
        return existing.iloc[:n_total].reset_index(drop=True)
    c_mean, c_std = existing["capacity_kg"].mean(), existing["capacity_kg"].std()
    c_min, c_max = existing["capacity_kg"].min(), existing["capacity_kg"].max()
    f_mean, f_std = existing["fixed_cost"].mean(), existing["fixed_cost"].std()
    f_min, f_max = existing["fixed_cost"].min(), existing["fixed_cost"].max()
    refrigs = existing["refrigeration_level"].values
    lats = np.random.uniform(LAT_MIN, LAT_MAX, n_new)
    lons = np.random.uniform(LON_MIN, LON_MAX, n_new)
    recs = []
    for k in range(n_new):
        recs.append({
            "dc_id": f"DC{n_existing+k+1}",
            "latitude": lats[k], "longitude": lons[k],
            "capacity_kg": int(np.clip(np.random.normal(c_mean, c_std), c_min, c_max)),
            "fixed_cost": int(np.clip(np.random.normal(f_mean, f_std), f_min, f_max)),
            "refrigeration_level": np.random.choice(refrigs),
        })
    return pd.concat([existing, pd.DataFrame(recs)], ignore_index=True)


def generate_charities(n_total, base_df):
    existing = base_df.copy()
    n_existing = len(existing)
    n_new = n_total - n_existing
    if n_new <= 0:
        return existing.iloc[:n_total].reset_index(drop=True)
    d_mean, d_std = existing["avg_daily_demand_kg"].mean(), existing["avg_daily_demand_kg"].std()
    d_min, d_max = existing["avg_daily_demand_kg"].min(), existing["avg_daily_demand_kg"].max()
    st_mean, st_std = existing["demand_std"].mean(), existing["demand_std"].std()
    st_min, st_max = existing["demand_std"].min(), existing["demand_std"].max()
    priorities = existing["priority_level"].values
    lats = np.random.uniform(LAT_MIN, LAT_MAX, n_new)
    lons = np.random.uniform(LON_MIN, LON_MAX, n_new)
    recs = []
    for k in range(n_new):
        recs.append({
            "charity_id": f"C{n_existing+k+1}",
            "latitude": lats[k], "longitude": lons[k],
            "avg_daily_demand_kg": int(np.clip(np.random.normal(d_mean, d_std), d_min, d_max)),
            "demand_std": int(np.clip(np.random.normal(st_mean, st_std), st_min, st_max)),
            "priority_level": np.random.choice(priorities),
        })
    return pd.concat([existing, pd.DataFrame(recs)], ignore_index=True)


def generate_distance_matrix(donors_df, dc_df, charity_df):
    rows = []
    # Donor-Donor (orijinal yapı için)
    for i in range(len(donors_df)):
        for j in range(i+1, len(donors_df)):
            d1, d2 = donors_df.iloc[i], donors_df.iloc[j]
            km = haversine_km(d1["latitude"], d1["longitude"], d2["latitude"], d2["longitude"])
            rows.append({"origin_id": d1["donor_id"], "destination_id": d2["donor_id"],
                         "distance_km": round(km, 2), "travel_time_min": round(km*TIME_PER_KM, 1)})
    # Donor-DC
    for _, d in donors_df.iterrows():
        for _, c in dc_df.iterrows():
            km = haversine_km(d["latitude"], d["longitude"], c["latitude"], c["longitude"])
            rows.append({"origin_id": d["donor_id"], "destination_id": c["dc_id"],
                         "distance_km": round(km, 2), "travel_time_min": round(km*TIME_PER_KM, 1)})
    # DC-Charity
    for _, c in dc_df.iterrows():
        for _, h in charity_df.iterrows():
            km = haversine_km(c["latitude"], c["longitude"], h["latitude"], h["longitude"])
            rows.append({"origin_id": c["dc_id"], "destination_id": h["charity_id"],
                         "distance_km": round(km, 2), "travel_time_min": round(km*TIME_PER_KM, 1)})
    return pd.DataFrame(rows)


def prepare_instance(name, config):
    """Instance veri klasörünü oluştur veya mevcut baseline'ı kullan."""
    if name == "medium":
        return BASE_DIR  # mevcut veri

    out_dir = os.path.join(BASE_DIR, f"data_{name}")
    if os.path.exists(out_dir) and all(
        os.path.exists(os.path.join(out_dir, f))
        for f in ["donors.csv", "distribution_centers.csv", "charities.csv",
                   "scenarios.csv", "distance_matrix.csv"]):
        print(f"  [{name}] Veri zaten var: {out_dir}", flush=True)
        return out_dir

    print(f"  [{name}] Veri üretiliyor: {out_dir}", flush=True)
    os.makedirs(out_dir, exist_ok=True)

    base_donors = pd.read_csv(os.path.join(BASE_DIR, "donors.csv"))
    base_dcs = pd.read_csv(os.path.join(BASE_DIR, "distribution_centers.csv"))
    base_charities = pd.read_csv(os.path.join(BASE_DIR, "charities.csv"))
    base_scenarios = pd.read_csv(os.path.join(BASE_DIR, "scenarios.csv"))

    # Her instance için seed'i reset et ki tutarlı olsun
    np.random.seed(RANDOM_SEED)

    donors_new = generate_donors(config["n_donor"], base_donors)
    dcs_new = generate_dcs(config["n_dc"], base_dcs)
    charities_new = generate_charities(config["n_charity"], base_charities)
    dist_new = generate_distance_matrix(donors_new, dcs_new, charities_new)

    donors_new.to_csv(os.path.join(out_dir, "donors.csv"), index=False)
    dcs_new.to_csv(os.path.join(out_dir, "distribution_centers.csv"), index=False)
    charities_new.to_csv(os.path.join(out_dir, "charities.csv"), index=False)
    base_scenarios.to_csv(os.path.join(out_dir, "scenarios.csv"), index=False)
    dist_new.to_csv(os.path.join(out_dir, "distance_matrix.csv"), index=False)

    print(f"  [{name}] Hazır: {len(donors_new)}D / {len(dcs_new)}DC / "
          f"{len(charities_new)}C", flush=True)
    return out_dir


# =============================================================================
# MODEL VE ÇÖZÜM (aug1.py'den uyarlandı)
# =============================================================================

def fmt_eta(s):
    if s < 60: return f"{s:.0f}sn"
    if s < 3600: return f"{s/60:.1f}dk"
    return f"{s/3600:.1f}sa"


def load_instance_data(data_dir):
    """Instance verilerini yükle ve model parametrelerini hesapla."""
    donors_df = pd.read_csv(os.path.join(data_dir, "donors.csv"))
    dc_df = pd.read_csv(os.path.join(data_dir, "distribution_centers.csv"))
    charity_df = pd.read_csv(os.path.join(data_dir, "charities.csv"))
    scenario_df = pd.read_csv(os.path.join(data_dir, "scenarios.csv"))
    dist_df = pd.read_csv(os.path.join(data_dir, "distance_matrix.csv"))

    donors = donors_df["donor_id"].tolist()
    dcs = dc_df["dc_id"].tolist()
    charities = charity_df["charity_id"].tolist()
    I, J, K, S = len(donors), len(dcs), len(charities), len(scenario_df)

    p_s = [1.0/S] * S
    supply_base = donors_df.set_index("donor_id")["avg_daily_surplus_kg"]
    demand_base = charity_df.set_index("charity_id")["avg_daily_demand_kg"]
    supply_mult = scenario_df["donor_supply_multiplier"].values
    demand_mult = scenario_df["demand_multiplier"].values

    S_is = {(i,s): float(supply_base[donors[i]]) * float(supply_mult[s])
             for i in range(I) for s in range(S)}
    D_ks = {(k,s): float(demand_base[charities[k]]) * float(demand_mult[s])
             for k in range(K) for s in range(S)}
    C_j = {j: float(dc_df.iloc[j]["capacity_kg"]) for j in range(J)}
    fc_j = {j: float(dc_df.iloc[j]["fixed_cost"]) for j in range(J)}
    refrig_cost_map = {"high": 1400.0, "medium": 1000.0, "low": 600.0}
    eps_j = {j: refrig_cost_map.get(dc_df.iloc[j]["refrigeration_level"], 1000.0)
              for j in range(J)}

    kappa0, theta, eps_ac, R_gas = 0.05, 4.0, 1500.0, 8.314
    kap = kappa0 * np.exp(-eps_ac / (R_gas * (theta+273.15)))
    max_shelf = donors_df["shelf_life_hours"].max()
    L_i = {did: 0.5 + 0.5 * (float(donors_df.loc[donors_df["donor_id"]==did,
                                                    "shelf_life_hours"].values[0])/max_shelf)
            for did in donors}

    dist_lookup = dist_df.set_index(["origin_id","destination_id"])["distance_km"].to_dict()
    def get_dist(o, d):
        v = dist_lookup.get((o,d))
        if v is not None: return float(v)
        v = dist_lookup.get((d,o))
        return float(v) if v is not None else 9999.0

    d_ij = {(i,j): get_dist(donors[i], dcs[j]) for i in range(I) for j in range(J)}
    d_jk = {(j,k): get_dist(dcs[j], charities[k]) for j in range(J) for k in range(K)}

    alpha_ij = {(i,j): min(max(1.0 - L_i[donors[i]] * np.exp(-kap*d_ij[i,j]), 0.0), 0.99)
                 for i in range(I) for j in range(J)}
    beta_jk = {(j,k): min(max(1.0 - np.exp(-kap*d_jk[j,k]), 0.0), 0.99)
                for j in range(J) for k in range(K)}

    total_demand_s = {s: sum(D_ks[k,s] for k in range(K)) for s in range(S)}

    return {
        "I": I, "J": J, "K": K, "S": S, "dcs": dcs,
        "p_s": p_s, "S_is": S_is, "D_ks": D_ks,
        "C_j": C_j, "fc_j": fc_j, "eps_j": eps_j,
        "d_ij": d_ij, "d_jk": d_jk,
        "alpha_ij": alpha_ij, "beta_jk": beta_jk,
        "total_demand_s": total_demand_s,
        "M_big": max(S_is.values()) * I * 1.5,
    }


def build_model(m, data, e1=None, e3=None, obj="Z2", method="epsilon",
                r1=1.0, r3=1.0, aug_eps=1e-4,
                MIN_SERVICE_RATE=0.30, gamma=0.05, phi=0.03, pi_p=2.0, eta=0.08):
    I,J,K,S = data["I"], data["J"], data["K"], data["S"]
    S_is, D_ks, C_j, fc_j, eps_j = data["S_is"], data["D_ks"], data["C_j"], data["fc_j"], data["eps_j"]
    d_ij, d_jk, alpha_ij, beta_jk = data["d_ij"], data["d_jk"], data["alpha_ij"], data["beta_jk"]
    p_s, total_demand_s, M_big = data["p_s"], data["total_demand_s"], data["M_big"]

    x = m.addVars(I, J, S, lb=0, name="x")
    r = m.addVars(I, J, S, lb=0, name="r")
    w = m.addVars(J, K, S, lb=0, name="w")
    y = m.addVars(J, K, S, lb=0, name="y")
    Omega = m.addVars(K, S, lb=0, ub=1, name="Omega")
    Omega_bar = m.addVars(S, lb=0, ub=1, name="Obar")
    u = m.addVars(K, S, lb=0, name="u")
    z = m.addVars(J, vtype=GRB.BINARY, name="z")

    s1 = m.addVar(lb=0, name="s1") if (method in ("augmecon","augmecon2") and e1 is not None) else None
    s3 = m.addVar(lb=0, name="s3") if (method in ("augmecon","augmecon2") and e3 is not None) else None
    m.update()

    transport_cost = gp.quicksum(
        p_s[s]*(gamma+phi)*(
            gp.quicksum(d_ij[i,j]*x[i,j,s] for i in range(I) for j in range(J)) +
            gp.quicksum(d_jk[j,k]*w[j,k,s] for j in range(J) for k in range(K))
        ) for s in range(S))
    penalty_cost = gp.quicksum(
        p_s[s]*(pi_p+eta)*(
            gp.quicksum(alpha_ij[i,j]*x[i,j,s] for i in range(I) for j in range(J)) +
            gp.quicksum(beta_jk[j,k]*w[j,k,s] for j in range(J) for k in range(K))
        ) for s in range(S))
    fixed_cost = gp.quicksum((fc_j[j]+eps_j[j])*z[j] for j in range(J))

    Z1_expr = transport_cost + penalty_cost + fixed_cost
    Z2_expr = gp.quicksum(p_s[s]*y[j,k,s] for s in range(S) for j in range(J) for k in range(K))
    Z3_expr = gp.quicksum(p_s[s]*u[k,s] for s in range(S) for k in range(K))

    for i in range(I):
        for s in range(S):
            m.addConstr(gp.quicksum(x[i,j,s] for j in range(J)) <= S_is[i,s])
    for i in range(I):
        for j in range(J):
            for s in range(S):
                m.addConstr(r[i,j,s] == (1.0-alpha_ij[i,j])*x[i,j,s])
    for j in range(J):
        for s in range(S):
            m.addConstr(gp.quicksum(r[i,j,s] for i in range(I)) ==
                         gp.quicksum(w[j,k,s] for k in range(K)))
            m.addConstr(gp.quicksum(r[i,j,s] for i in range(I)) <= C_j[j]*z[j])
    for j in range(J):
        for k in range(K):
            for s in range(S):
                m.addConstr(y[j,k,s] == (1.0-beta_jk[j,k])*w[j,k,s])
    for k in range(K):
        for s in range(S):
            m.addConstr(gp.quicksum(y[j,k,s] for j in range(J)) <= D_ks[k,s])
            m.addConstr(Omega[k,s]*D_ks[k,s] == gp.quicksum(y[j,k,s] for j in range(J)))
    for s in range(S):
        m.addConstr(Omega_bar[s]*K == gp.quicksum(Omega[k,s] for k in range(K)))
    for k in range(K):
        for s in range(S):
            m.addConstr(u[k,s] >= Omega[k,s]-Omega_bar[s])
            m.addConstr(u[k,s] >= Omega_bar[s]-Omega[k,s])
    for i in range(I):
        for j in range(J):
            for s in range(S):
                m.addConstr(x[i,j,s] <= M_big*z[j])
    for j in range(J):
        for k in range(K):
            for s in range(S):
                m.addConstr(y[j,k,s] <= M_big*z[j])
    for s in range(S):
        m.addConstr(gp.quicksum(y[j,k,s] for j in range(J) for k in range(K))
                     >= MIN_SERVICE_RATE*total_demand_s[s])

    if method == "epsilon":
        if e1 is not None: m.addConstr(Z1_expr <= e1)
        if e3 is not None: m.addConstr(Z3_expr <= e3)
    else:
        if e1 is not None and s1 is not None: m.addConstr(Z1_expr + s1 == e1)
        if e3 is not None and s3 is not None: m.addConstr(Z3_expr + s3 == e3)

    if obj == "Z1":
        m.setObjective(Z1_expr, GRB.MINIMIZE)
    elif obj == "Z3":
        m.setObjective(Z3_expr, GRB.MINIMIZE)
    elif method == "epsilon":
        m.setObjective(Z2_expr, GRB.MAXIMIZE)
    elif method == "augmecon":
        aug = 0.0
        if s1 is not None: aug += aug_eps*s1
        if s3 is not None: aug += aug_eps*s3
        m.setObjective(Z2_expr + aug, GRB.MAXIMIZE)
    elif method == "augmecon2":
        aug = 0.0
        if s1 is not None and r1 > 0: aug += aug_eps*(s1/r1)
        if s3 is not None and r3 > 0: aug += aug_eps*1e-1*(s3/r3)
        m.setObjective(Z2_expr + aug, GRB.MAXIMIZE)

    return Z1_expr, Z2_expr, Z3_expr, z, s1, s3


def solve_one(data, e1=None, e3=None, obj="Z2", method="epsilon",
              r1=1.0, r3=1.0, aug_eps=1e-4, fixed_objectives=None, time_limit=120):
    m = gp.Model()
    m.setParam("OutputFlag", 0)
    m.setParam("TimeLimit", time_limit)
    m.setParam("Seed", RANDOM_SEED)

    Z1_expr, Z2_expr, Z3_expr, z, s1, s3 = build_model(
        m, data, e1=e1, e3=e3, obj=obj, method=method,
        r1=r1, r3=r3, aug_eps=aug_eps)

    if fixed_objectives:
        for name, val in fixed_objectives.items():
            tol = max(1e-3, 1e-4*abs(val))
            if name == "Z1":
                m.addConstr(Z1_expr <= val+tol); m.addConstr(Z1_expr >= val-tol)
            elif name == "Z2":
                m.addConstr(Z2_expr <= val+tol); m.addConstr(Z2_expr >= val-tol)
            elif name == "Z3":
                m.addConstr(Z3_expr <= val+1e-4); m.addConstr(Z3_expr >= val-1e-4)

    m.optimize()
    if m.Status not in (GRB.OPTIMAL, GRB.TIME_LIMIT) or m.SolCount == 0:
        m.dispose()
        return None

    try: mip_gap = m.MIPGap
    except: mip_gap = 0.0

    J = data["J"]
    result = {
        "Z1": Z1_expr.getValue(), "Z2": Z2_expr.getValue(), "Z3": Z3_expr.getValue(),
        "z": {j: round(z[j].X) for j in range(J)},
        "s1": s1.X if s1 is not None else None,
        "s3": s3.X if s3 is not None else None,
        "mip_gap": mip_gap, "status": m.Status,
    }
    m.dispose()
    return result


def compute_payoff(data):
    s = solve_one(data, obj="Z1", method="epsilon")
    if s is None: return None
    Z1_star = s["Z1"]
    s = solve_one(data, obj="Z2", method="epsilon", fixed_objectives={"Z1": Z1_star})
    Z2_at = s["Z2"]
    s = solve_one(data, obj="Z3", method="epsilon", fixed_objectives={"Z1": Z1_star, "Z2": Z2_at})
    Z3_at = s["Z3"]
    row1 = {"Z1": Z1_star, "Z2": Z2_at, "Z3": Z3_at}

    s = solve_one(data, obj="Z2", method="epsilon")
    Z2_star = s["Z2"]
    s = solve_one(data, obj="Z1", method="epsilon", fixed_objectives={"Z2": Z2_star})
    Z1_at = s["Z1"]
    s = solve_one(data, obj="Z3", method="epsilon", fixed_objectives={"Z2": Z2_star, "Z1": Z1_at})
    Z3_at = s["Z3"]
    row2 = {"Z1": Z1_at, "Z2": Z2_star, "Z3": Z3_at}

    s = solve_one(data, obj="Z3", method="epsilon")
    Z3_star = s["Z3"]
    s = solve_one(data, obj="Z1", method="epsilon", fixed_objectives={"Z3": Z3_star})
    Z1_at = s["Z1"]
    s = solve_one(data, obj="Z2", method="epsilon", fixed_objectives={"Z3": Z3_star, "Z1": Z1_at})
    Z2_at = s["Z2"]
    row3 = {"Z1": Z1_at, "Z2": Z2_at, "Z3": Z3_star}

    Z1_vals = [row1["Z1"], row2["Z1"], row3["Z1"]]
    Z2_vals = [row1["Z2"], row2["Z2"], row3["Z2"]]
    Z3_vals = [row1["Z3"], row2["Z3"], row3["Z3"]]
    Z1_ideal, Z1_nadir = min(Z1_vals), max(Z1_vals)
    Z2_ideal, Z2_nadir = max(Z2_vals), min(Z2_vals)
    Z3_ideal, Z3_nadir = min(Z3_vals), max(Z3_vals)
    if Z3_nadir - Z3_ideal < 1e-4:
        Z3_nadir = Z3_ideal + 0.5
    r1 = max(Z1_nadir-Z1_ideal, 1e-6)
    r3 = max(Z3_nadir-Z3_ideal, 1e-6)
    return {
        "Z1_ideal": Z1_ideal, "Z1_nadir": Z1_nadir,
        "Z2_ideal": Z2_ideal, "Z2_nadir": Z2_nadir,
        "Z3_ideal": Z3_ideal, "Z3_nadir": Z3_nadir,
        "r1": r1, "r3": r3,
    }


def filter_pareto(solutions):
    solutions = [s for s in solutions if s["Z2"] > 1e-3]
    if not solutions: return []
    bucket = {}
    for s in solutions:
        key = (round(s["Z1"], -1), round(s["Z2"]), round(s["Z3"], 2))
        if key not in bucket or s["Z1"] < bucket[key]["Z1"] - 1e-6:
            bucket[key] = s
    unique = list(bucket.values())
    pareto = []
    for i, a in enumerate(unique):
        t1 = max(10.0, 1e-3*abs(a["Z1"]))
        t2 = max(1.0, 1e-3*abs(a["Z2"]))
        t3 = max(1e-3, 1e-3*abs(a["Z3"]))
        dominated = False
        for j, b in enumerate(unique):
            if i == j: continue
            if (b["Z1"] <= a["Z1"]+t1 and b["Z2"] >= a["Z2"]-t2 and b["Z3"] <= a["Z3"]+t3 and
                (b["Z1"] < a["Z1"]-t1 or b["Z2"] > a["Z2"]+t2 or b["Z3"] < a["Z3"]-t3)):
                dominated = True; break
        if not dominated: pareto.append(a)
    return pareto


def run_method(data, payoff, method, n1=15, n3=20, aug_eps=None):
    """Tek yöntemi çalıştır."""
    if aug_eps is None:
        aug_eps = 1e-6 if method == "augmecon" else (1e-3 if method == "augmecon2" else None)

    Z1_ideal, Z1_nadir = payoff["Z1_ideal"], payoff["Z1_nadir"]
    Z3_ideal, Z3_nadir = payoff["Z3_ideal"], payoff["Z3_nadir"]
    r1, r3 = payoff["r1"], payoff["r3"]

    t0 = time.time()
    solutions, models_solved = [], 0
    e3_vals = np.linspace(Z3_nadir, Z3_ideal, n3)
    e1_vals = np.linspace(Z1_nadir, Z1_ideal, n1)
    step1 = abs(e1_vals[1]-e1_vals[0]) if len(e1_vals) > 1 else 1.0

    print(f"  [{method}] Başladı (grid {n3}x{n1}={n3*n1})", flush=True)

    for i_e3, e3 in enumerate(e3_vals):
        row_t = time.time()
        if method == "augmecon2":
            j1 = 0
            while j1 < len(e1_vals):
                e1 = e1_vals[j1]
                sol = solve_one(data, e1=e1, e3=e3, obj="Z2", method=method,
                                 r1=r1, r3=r3, aug_eps=aug_eps)
                models_solved += 1
                if sol:
                    sol["e1"] = e1; sol["e3"] = e3
                    solutions.append(sol)
                    jump = max(0, int(sol["s1"]/step1)) if sol["s1"] is not None and step1 > 1e-9 else 0
                    j1 += jump + 1
                else:
                    break
        else:
            for e1 in e1_vals:
                sol = solve_one(data, e1=e1, e3=e3, obj="Z2", method=method,
                                 r1=r1, r3=r3, aug_eps=aug_eps if aug_eps else 1e-4)
                models_solved += 1
                if sol:
                    sol["e1"] = e1; sol["e3"] = e3
                    solutions.append(sol)

        if (i_e3+1) % 5 == 0:
            elapsed = time.time()-t0
            progress = (i_e3+1)/n3
            eta = elapsed/progress - elapsed
            print(f"    satır {i_e3+1}/{n3} | toplam {fmt_eta(elapsed)} | "
                  f"ETA {fmt_eta(eta)}", flush=True)

    elapsed = time.time()-t0
    pareto = filter_pareto(solutions)
    print(f"  [{method}] BİTTİ | Model: {models_solved} | Pareto: {len(pareto)} | "
          f"Süre: {fmt_eta(elapsed)}", flush=True)
    return pareto, models_solved, elapsed, solutions


# =============================================================================
# ANA — INSTANCE DÖNGÜSÜ
# =============================================================================

def main():
    print("="*72, flush=True)
    print(" SCALABILITY TEST — Hakem #8 Cevabı İçin", flush=True)
    print(f" Seed: {RANDOM_SEED} | Instance'lar: {list(INSTANCES.keys())}", flush=True)
    print("="*72, flush=True)

    overall_t = time.time()
    all_results = []
    all_pareto_rows = []

    for inst_name, config in INSTANCES.items():
        print(f"\n{'#'*72}", flush=True)
        print(f"# INSTANCE: {inst_name.upper()} ({config['n_donor']}D / "
              f"{config['n_dc']}DC / {config['n_charity']}C)", flush=True)
        print(f"{'#'*72}", flush=True)

        # 1. Veriyi hazırla
        data_dir = prepare_instance(inst_name, config)

        # 2. Instance verisini yükle
        data = load_instance_data(data_dir)
        print(f"  Veri yüklendi: {data['I']}D / {data['J']}DC / "
              f"{data['K']}C / {data['S']}S", flush=True)

        # 3. Payoff hesapla
        print(f"\n  Payoff hesaplanıyor...", flush=True)
        payoff = compute_payoff(data)
        if payoff is None:
            print(f"  HATA: {inst_name} payoff hesaplanamadı, atlanıyor", flush=True)
            continue
        print(f"  Z1=[{payoff['Z1_ideal']:,.0f}-{payoff['Z1_nadir']:,.0f}] "
              f"Z2=[{payoff['Z2_nadir']:,.0f}-{payoff['Z2_ideal']:,.0f}] "
              f"Z3=[{payoff['Z3_ideal']:.3f}-{payoff['Z3_nadir']:.3f}]", flush=True)

        # 4. 3 yöntemi çalıştır
        for method in ["epsilon", "augmecon", "augmecon2"]:
            print(f"\n  ---- {method.upper()} ----", flush=True)
            pareto, models, cpu, all_sols = run_method(
                data, payoff, method, n1=config["n1"], n3=config["n3"])

            # Özet
            gaps = [s["mip_gap"] for s in all_sols if s is not None]
            all_results.append({
                "instance": inst_name,
                "n_donor": config["n_donor"],
                "n_dc": config["n_dc"],
                "n_charity": config["n_charity"],
                "method": method,
                "n_pareto": len(pareto),
                "n_models": models,
                "cpu_sec": cpu,
                "avg_gap_pct": 100*np.mean(gaps) if gaps else 0,
                "max_gap_pct": 100*np.max(gaps) if gaps else 0,
                "pct_optimal": 100*np.sum(np.array(gaps) < 1e-4)/len(gaps) if gaps else 0,
                "Z1_min": min(s["Z1"] for s in pareto) if pareto else None,
                "Z1_max": max(s["Z1"] for s in pareto) if pareto else None,
                "Z2_min": min(s["Z2"] for s in pareto) if pareto else None,
                "Z2_max": max(s["Z2"] for s in pareto) if pareto else None,
                "Z3_min": min(s["Z3"] for s in pareto) if pareto else None,
                "Z3_max": max(s["Z3"] for s in pareto) if pareto else None,
            })

            # Pareto çözümlerini kaydet
            for p in pareto:
                all_pareto_rows.append({
                    "instance": inst_name, "method": method,
                    "Z1": p["Z1"], "Z2": p["Z2"], "Z3": p["Z3"],
                    "mip_gap": p["mip_gap"],
                    "open_DCs": str([data["dcs"][j] for j in range(data["J"])
                                      if p["z"][j] > 0.5]),
                })

            # Ara kayıt (uzun süren işte güvenlik için)
            pd.DataFrame(all_results).to_csv(
                os.path.join(BASE_DIR, "scalability_summary.csv"), index=False)
            pd.DataFrame(all_pareto_rows).to_csv(
                os.path.join(BASE_DIR, "scalability_pareto.csv"), index=False)

    # SON ÖZET
    total = time.time() - overall_t
    print(f"\n{'='*72}", flush=True)
    print(f"TÜM TESTLER BİTTİ — Toplam süre: {fmt_eta(total)}", flush=True)
    print(f"{'='*72}\n", flush=True)

    df = pd.DataFrame(all_results)
    print("ÖZET TABLO:", flush=True)
    print(df[["instance","method","n_pareto","n_models","cpu_sec",
              "avg_gap_pct","pct_optimal"]].to_string(index=False), flush=True)
    print(f"\nKaydedilenler:", flush=True)
    print(f"  → scalability_summary.csv", flush=True)
    print(f"  → scalability_pareto.csv", flush=True)


if __name__ == "__main__":
    main()